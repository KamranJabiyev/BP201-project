﻿using System.IO;

namespace WebUI.Helpers
{
    public static class Helper
    {
        public static string GetPath(string root, params string[] folders)
        {
            string resultPath = root;
            foreach (var folder in folders)
            {
                resultPath = Path.Combine(resultPath, folder);
            }
            return resultPath;
        }
    }
}

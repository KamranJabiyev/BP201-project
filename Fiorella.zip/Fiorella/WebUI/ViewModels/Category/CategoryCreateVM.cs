﻿using System.ComponentModel.DataAnnotations;

namespace WebUI.ViewModels.Categories
{
    public class CategoryCreateVM
    {
        [Required(ErrorMessage ="Boş buraxmaq olmaz!!!")]
        public string Name { get; set; }
    }
}

﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using System;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using WebUI.DAL;
using WebUI.Helpers;
using WebUI.Models;

namespace WebUI.Areas.AdminPanel.Controllers
{
    [Area("AdminPanel")]
    public class SliderController : Controller
    {
        private AppDbContext _context { get;}
        private IWebHostEnvironment _env { get; }
        private int countSlider { get; }
        private int sliderMaxCount { get; }

        public SliderController(AppDbContext context, IWebHostEnvironment env)
        {
            _context=context;
            _env = env;
            countSlider = _context.Slides.Count();
            sliderMaxCount=int.Parse(_context.Settings.ToDictionary(s => s.Key, s => s.Value)["slider_max_count"]);
        }
        public IActionResult Index()
        {
            ViewBag.slideCount= countSlider;
            ViewBag.sliderMaxCount=sliderMaxCount;
            return View(_context.Slides);
        }

        public IActionResult Create()
        {
            if (countSlider >= sliderMaxCount)
            {
                return Content("Caaan...");
            }
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Slide slide)
        {
            if (!ModelState.IsValid) return View();
            if(slide.Photos.Count+ countSlider > sliderMaxCount)
            {
                ModelState
                    .AddModelError("", $"Maximum count of slider must be {sliderMaxCount}." +
                    $" You can create {sliderMaxCount - countSlider} photos");
                return View();
            }

            string errorMessage=String.Empty;
            foreach (var photo in slide.Photos)
            {
                if (!photo.CheckFileType("image/"))
                {
                    errorMessage += $"Type of file({photo.FileName}) must be image.\n";
                }
                if (!photo.CheckFileSize(200))
                {
                    errorMessage+=$"Max size of image({photo.FileName}) must be less than 200kb.\n";
                }
            }
            if(errorMessage != String.Empty)
            {
                ModelState.AddModelError("Photos", errorMessage);
                return View();
            }
            foreach (var photo in slide.Photos)
            {
                Slide newSlide = new Slide();
                newSlide.Url= await photo.SaveFileAsync(_env.WebRootPath,"img");
                await _context.Slides.AddAsync(newSlide);
            }
            await _context.SaveChangesAsync();
            #region MyRegion
            //if (!ModelState.IsValid)
            //{
            //    return View();
            //}
            //if (!slide.Photo.CheckFileSize(200))
            //{
            //    ModelState.AddModelError("Photo", "Max size of image must be less than 200kb");
            //    return View();
            //}
            //if (!slide.Photo.CheckFileType("image/"))
            //{
            //    ModelState.AddModelError("Photo", "Type of file must be image");
            //    return View();
            //}

            //slide.Url =await slide.Photo.SaveFileAsync(_env.WebRootPath,"img");
            //await _context.Slides.AddAsync(slide);
            //await _context.SaveChangesAsync();
            #endregion

            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null) return BadRequest();
            var slider = _context.Slides.Find(id);
            if (slider == null) return NotFound();
            var path=Helper.GetPath(_env.WebRootPath,"img",slider.Url);
            if (System.IO.File.Exists(path))
            {
                System.IO.File.Delete(path);
            }
            _context.Slides.Remove(slider);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }
    }
}

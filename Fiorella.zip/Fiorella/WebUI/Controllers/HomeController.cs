﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using WebUI.DAL;
using WebUI.Models;
using WebUI.ViewModels;

namespace WebUI.Controllers
{
    public class HomeController : Controller
    {
        private AppDbContext _context { get; }
        private int _count { get; }
        public HomeController(AppDbContext context)
        {
            _context=context;
            _count=context.Products.Where(p=>!p.IsDeleted).Count();
        }
        public IActionResult Index()
        {
            //HttpContext.Session.SetString("name", "Ali");
            //HttpContext.Response.Cookies.Append("surname", "Veliyev",
            //    new CookieOptions { MaxAge=TimeSpan.FromSeconds(20)});
            ViewBag.ProductCount = _count;
            HomeViewModel home = new HomeViewModel
            {
                Slides= _context.Slides.ToList(),
                Summary= _context.Summary.FirstOrDefault(),
                Categories= _context.Categories.Where(c=>!c.IsDeleted).ToList(),
                Products= _context.Products.Where(c=>!c.IsDeleted)
                .Include(p=>p.Images).Include(p=>p.Category).OrderByDescending(p => p.Id)
                .Take(8).ToList()
            };
            return View(home);
        }

        public IActionResult LoadProducts(int skip=8)
        {
            if (skip >=_count) {
                return BadRequest();
            }
            List<Product> products = _context.Products.Where(c => !c.IsDeleted)
                .Include(p => p.Images).Include(p => p.Category).OrderByDescending(p => p.Id)
                .Skip(skip).Take(8).ToList();
            //return Json(products);
            return PartialView("_ProductPartial", products);
        }
        public IActionResult GetSession()
        {
            string session=HttpContext.Session.GetString("name");
            string cookie = HttpContext.Request.Cookies["surname"];
            return Json(session+" - "+ cookie);
        }
    }
}
